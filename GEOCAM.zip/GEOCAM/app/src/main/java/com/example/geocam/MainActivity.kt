package com.example.geocam

import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

// Definición de Colores Pasteles Estéticos
val AmarilloPastel = Color(0xFFFFF9C4)
val VerdePastel = Color(0xFFC8E6C9)
val VerdeFuerte = Color(0xFF2E7D32)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()

            // Navegación entre pantallas
            NavHost(navController = navController, startDestination = "bienvenida") {
                composable("bienvenida") {
                    PantallaBienvenida { navController.navigate("lista") }
                }
                composable("lista") {
                    PantallaListaLugares { lugar -> navController.navigate("detalle/$lugar") }
                }
                composable("detalle/{lugar}") { backStackEntry ->
                    val lugar = backStackEntry.arguments?.getString("lugar") ?: ""
                    PantallaDetalle(lugar) { navController.popBackStack() }
                }
            }
        }
    }
}

@Composable
fun PantallaBienvenida(onExplorarClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(AmarilloPastel).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "¡Bienvenido a la\nGarganta del Sol!",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = VerdeFuerte,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(40.dp))
        Button(
            onClick = onExplorarClick,
            colors = ButtonDefaults.buttonColors(containerColor = VerdeFuerte),
            shape = RoundedCornerShape(15.dp)
        ) {
            Text("Explorar Campeche", color = Color.White, fontSize = 18.sp)
        }
    }
}

@Composable
fun PantallaListaLugares(onLugarClick: (String) -> Unit) {
    val lugares = listOf("Bécal", "Isla Arena", "El Remate", "Calkiní Centro")

    Column(modifier = Modifier.fillMaxSize().background(VerdePastel).padding(16.dp)) {
        Text("Destinos Turísticos", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(lugares) { lugar ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = lugar, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Descubre la magia de este sitio.")
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = { onLugarClick(lugar) }) {
                            Text("Explorar este lugar")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PantallaDetalle(nombre: String, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        Text(text = nombre, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = VerdeFuerte)
        Spacer(modifier = Modifier.height(10.dp))

        Text("Guía Relevante:", fontWeight = FontWeight.Bold)
        Text("• Cultura: Artesanías de jipi-japa y tradiciones.\n• Conveniencia: Restaurantes y paradores cercanos.\n• Turismo: Zonas arqueológicas y ecoturismo.")

        Spacer(modifier = Modifier.height(30.dp))

        // Espacio para el mapa
        Surface(
            modifier = Modifier.fillMaxWidth().height(250.dp),
            color = Color.LightGray,
            shape = RoundedCornerShape(15.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("Cargando Mapa de $nombre...", textAlign = TextAlign.Center)
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("Volver al Menú")
        }
    }
}